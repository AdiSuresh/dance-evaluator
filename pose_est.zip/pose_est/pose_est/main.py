from pose_est.capture_pose import *

video_path = r'./videos/young-man-walking-listening-to-music-from-his-headphones.mp4'

if __name__ == "__main__":
    print(start_capture(path=0, save_output=True))
