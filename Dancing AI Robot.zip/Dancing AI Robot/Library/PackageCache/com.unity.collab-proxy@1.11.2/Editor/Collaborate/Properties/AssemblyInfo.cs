using System;
using System.Runtime.CompilerServices;

[assembly: InternalsVisibleToAttribute("Unity.CollabProxy.EditorTests")]
